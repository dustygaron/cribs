/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SortByPipe } from './sort-by.pipe';

describe('SortByPipe', () => {
  it('create an instance', () => {
    let pipe = new SortByPipe();
    expect(pipe).toBeTruthy();
  });
});
